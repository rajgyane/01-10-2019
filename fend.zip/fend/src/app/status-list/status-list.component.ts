import { Component,  OnInit,ViewChild, ViewChildren} from '@angular/core';

import {LeadSource} from '../lead-source';
import {LeadserviceService} from '../leadservice.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-status-list',
  templateUrl: './status-list.component.html',
  styleUrls: ['./status-list.component.css']
})
export class StatusListComponent implements OnInit {

leadsourcestatus_data:LeadSource[]=[];
dataSource: MatTableDataSource<LeadSource>;

@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;

displayedColumns: string[] = ['Srno','lead_source_name','actions'];

role_type:string;
  constructor(private ls:LeadserviceService) { }

  ngOnInit() {
    this.role_type=localStorage.getItem('assign_role');
  this.gwtLeadSourceData();
         
  }

gwtLeadSourceData(){
  this.ls
      .getLeadsourcedata()
      .subscribe((data: LeadSource[]) => {
        this.leadsourcestatus_data = data;
        
        this.dataSource = new MatTableDataSource(this.leadsourcestatus_data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
              });

}



  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  

}
