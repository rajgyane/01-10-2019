export class Class {
    class_id:String;
    class_name:String;
}
