import { Component, OnInit,Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {LeadserviceService} from '../leadservice.service';
import{ ActivatedRoute,Router} from '@angular/router';
import { LeadSource} from '../lead-source';

@Component({
  selector: 'app-addleadsource',
  templateUrl: './addleadsource.component.html',
  styleUrls: ['./addleadsource.component.css']
})
export class AddleadsourceComponent implements OnInit {
  angForm: FormGroup;
  leadsourcedata:LeadSource[]=[];
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,private fb: FormBuilder,private ls:LeadserviceService,private route: ActivatedRoute,
  private router: Router) {this.createForm(); }
  createForm() {
    this.angForm = this.fb.group({
      
      leadsource: ['', Validators.required ]
      
    });
  }
  ngOnInit() {
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  add_leadsource()
  {
    let leadsource=this.angForm.value.leadsource;
    this.ls
    .add_leadsourcedata(leadsource)
    .subscribe((data: LeadSource[]) => {
      this.leadsourcedata = data;
      //console.log(this.leadsourcedata);
      
});
  }

}
