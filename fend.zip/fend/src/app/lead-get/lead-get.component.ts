import {Component, OnInit,ViewChild } from '@angular/core';
import{ LeadserviceService } from '../leadservice.service';
import  lead  from '../lead';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import {ViewdetailsComponent} from '../viewdetails/viewdetails.component';
import { AddfollowupstatusComponent} from '../addfollowupstatus/addfollowupstatus.component';
import { AddleadsourceComponent } from '../addleadsource/addleadsource.component';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { MessageboxComponent} from '../messagebox/messagebox.component';





@Component({
  selector: 'app-lead-get',
  templateUrl: './lead-get.component.html',
  styleUrls: ['./lead-get.component.css']
})
export class LeadGetComponent implements OnInit  {
 
Lead:lead[]= [];
followup_status_array=[];
dataSource: MatTableDataSource<lead>;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
role_type:string;
show = true;  

displayedColumns: string[] = ['Srno','student_name', 'mobile_no', 'email_address', 'class_apply','leadsource','status','actions'];



// MatPaginator Output


 
private postsSub: Subscription;
private authStatusSub: Subscription;
  constructor(private ls:LeadserviceService,private route: ActivatedRoute,
    private router: Router,public dialog: MatDialog) { }
    
    
  ngOnInit() {
    this.Lead=[];
    this.role_type=localStorage.getItem('assign_role');
    this.postsSub =this.ls
      .getLead()
      .subscribe((data: lead[]) => {
        this.Lead = data;
        console.log(this.Lead);
        this.show = false;
        this.dataSource = new MatTableDataSource(this.Lead);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    
  
    
        
    });
    
    
   

  }

  
  
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  add_user(v)
    {
      //console.log(v);
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='700px';
      
      dialogConfig1.data={id: v};

      const dialogRef = this.dialog.open(ViewdetailsComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
     
    }
    add_status()
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='350px';
      
     
      const dialogRef = this.dialog.open(AddfollowupstatusComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
    }
    add_lead_source()
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='350px';
      
     
      const dialogRef = this.dialog.open(AddleadsourceComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
    }
  deleteLead(id) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width='300px';
    dialogConfig.height='250px';

    dialogConfig.data = {
    id: 1,
    title: 'Conformation Box',question:'Do you want to remove ?'

    };
    const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='250px';
    dialogConfig1.height='180px';

    const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
    if(result==true)
    {
      //console.log(id);
      this.ls.deleteLead(id).subscribe(res => {
        
          dialogConfig1.data = {
          
            response_data:res
      
          };
          dialogConfig1.width='250px';
          dialogConfig1.height='200px';
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
    });
    this.ngOnInit();
      
    }
    });
    
  }
  editDetails(id)
  {
    this.router.navigate(['/edit',id]);

  }
  followupsDetails(id)
  {
    this.router.navigate(['/followup',id]);
  }
  viewDetails(id)
  {
    this.router.navigate(['/viewfollowup',id]);
  }
  
  

}


