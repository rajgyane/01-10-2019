import { Component, OnInit ,Inject, ComponentFactoryResolver} from '@angular/core';
import {  MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {LeadSource} from '../../lead-source';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {LeadserviceService} from '../../leadservice.service';

@Component({
  selector: 'app-editleadsourcelist',
  templateUrl: './editleadsourcelist.component.html',
  styleUrls: ['./editleadsourcelist.component.css']
})
export class EditleadsourcelistComponent implements OnInit {
  angForm: FormGroup;
  lead_source_data:LeadSource[]=[];
  response:string;
  constructor( public dialogRef: MatDialogRef<LeadSource>,@Inject(MAT_DIALOG_DATA) public data: any,public fb:FormBuilder,private ls:LeadserviceService)
   {this.createForm(); }
   createForm() {
    this.angForm = this.fb.group({
      
      leadsource: ['', Validators.required ]
      
    });
  }

  ngOnInit() {
    this.ls
    .edit_lead_source_data(this.data.id)
    .subscribe((data: LeadSource[]) => {
      this.lead_source_data = data;
      this.angForm.patchValue({leadsource:'1'});
      //console.log(this.lead_source_data);
     });
    //console.log(this.data.id);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  edit_leadsource(value)
  {
    let source_name=value;
    let action_id=this.data.id;
    this.ls
    .edit_lead_source_data_update(source_name,action_id)
    .subscribe((data: any) => {
      this.response = data;
      //console.log(this.response);
      
     });
    
  }

}
