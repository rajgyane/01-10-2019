import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule,MatFormFieldModule ,MatInputModule} from '@angular/material';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatDialogModule, MatButtonModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import {  StatuslisttypeComponent } from './statuslisttype.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import{ ReactiveFormsModule,FormsModule} from '@angular/forms';

import { LeadsourcelistComponent } from './leadsourcelist/leadsourcelist.component';
import { FollowupstatuslistComponent } from './followupstatuslist/followupstatuslist.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { EditfollowupstatuslistComponent } from './editfollowupstatuslist/editfollowupstatuslist.component';
import { EditleadsourcelistComponent } from './editleadsourcelist/editleadsourcelist.component';
import {MatIconModule} from '@angular/material/icon';
import { DeletestatusdataComponent } from './deletestatusdata/deletestatusdata.component';
import { AddfollowupstatusComponent } from './addfollowupstatus/addfollowupstatus.component';
import { AddleadsourceComponent } from './addleadsource/addleadsource.component';


@NgModule({
 /*
  imports: [
    CommonModule,MatTabsModule,RouterModule.forChild([
      { path: '', component: StatuslisttypeComponent, children: [
        { path: '', redirectTo: 'Leadsourcelist'},
        { path: 'Leadsourcelist', component: LeadsourcelistComponent, data: { label: 'Lead Source List' } },
        { path: 'followupstatuslist', component: FollowupstatuslistComponent, data: { label: 'Follow Up Status List' } }
      ] }
    ])
  ],declarations: [LeadsourcelistComponent, FollowupstatuslistComponent, StatuslisttypeComponent]*/
  imports: [
    CommonModule,MatTabsModule, ReactiveFormsModule,FormsModule,MatIconModule,MatDialogModule,MatToolbarModule, MatButtonModule,MatFormFieldModule,MatProgressSpinnerModule,MatTableModule,MatInputModule,MatSortModule,MatPaginatorModule,RouterModule.forChild([
      { path: 'statuslisttype', component: StatuslisttypeComponent, children: [
        { path: '', redirectTo: 'Leadsourcelist',pathMatch:'full'},
        { path: 'Leadsourcelist', component: LeadsourcelistComponent, data: { label: 'Lead Source List' } },
        //{ path: 'Leadsourcelist', component: LeadsourcelistComponent, data: { label: 'Lead Source List' } },
        { path: 'followupstatuslist', component: FollowupstatuslistComponent, data: { label: 'Follow Up Status List' } }
      ] }
    ])
  ],declarations: [LeadsourcelistComponent, FollowupstatuslistComponent, StatuslisttypeComponent, EditfollowupstatuslistComponent, EditleadsourcelistComponent, DeletestatusdataComponent, AddfollowupstatusComponent, AddleadsourceComponent]
  ,entryComponents: [EditfollowupstatuslistComponent,EditleadsourcelistComponent,DeletestatusdataComponent,AddfollowupstatusComponent,AddleadsourceComponent],
})
export class StatuslisttypeModule { }
