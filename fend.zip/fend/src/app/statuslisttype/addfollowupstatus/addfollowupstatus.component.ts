import { Component, OnInit ,Inject} from '@angular/core';
import {  MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { Followupstatus} from '../../followupstatus';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {LeadserviceService} from '../../leadservice.service';

@Component({
  selector: 'app-addfollowupstatus',
  templateUrl: './addfollowupstatus.component.html',
  styleUrls: ['./addfollowupstatus.component.css']
})
export class AddfollowupstatusComponent implements OnInit {

  angForm: FormGroup;
  response:string;
  followup_status_data:Followupstatus[]=[];
  constructor(public dialogRef: MatDialogRef<Followupstatus>,@Inject(MAT_DIALOG_DATA) public data: any,public fb:FormBuilder,private ls:LeadserviceService)
   {this.createForm();  }
   createForm() {
    this.angForm = this.fb.group({
      
      followupstatus: ['', Validators.required ]
      
    });
  }

  ngOnInit() {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  add_followups()
  {
    let followups=this.angForm.value.followupstatus;
    this.ls
    .add_followupsstatus(followups)
    .subscribe((data: Followupstatus[]) => {
      this.followup_status_data = data;
      //console.log(this.fstatus_data);
      
});

  }

}
