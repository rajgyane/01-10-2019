import { Component, OnInit ,Inject, ComponentFactoryResolver} from '@angular/core';
import {  MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {LeadSource} from '../../lead-source';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {LeadserviceService} from '../../leadservice.service';

@Component({
  selector: 'app-addleadsource',
  templateUrl: './addleadsource.component.html',
  styleUrls: ['./addleadsource.component.css']
})
export class AddleadsourceComponent implements OnInit {
  angForm: FormGroup;
  lead_source_data:LeadSource[]=[];
  response:string;
  constructor( public dialogRef: MatDialogRef<LeadSource>,@Inject(MAT_DIALOG_DATA) public data: any,public fb:FormBuilder,private ls:LeadserviceService)
   {this.createForm(); }

  ngOnInit() {
  }
  createForm() {
    this.angForm = this.fb.group({
      
      leadsource: ['', Validators.required ]
      
    });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  add_leadsource()
  {
    let leadsource=this.angForm.value.leadsource;
    this.ls
    .add_leadsourcedata(leadsource)
    .subscribe((data: LeadSource[]) => {
      this.lead_source_data = data;
      //console.log(this.leadsourcedata);
      
});
  }

}
