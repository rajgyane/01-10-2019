import { Component, OnInit , ViewChild,Inject} from '@angular/core';
import { LeadserviceService } from '../leadservice.service';
import  { User}  from '../user';
import { RoleType} from '../role-type';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import { AddUserComponent} from '../add-user/add-user.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  user_list:User[]= [];
  assign_role:RoleType[]=[];
  status_update:any;
  show = true;  
  dataSource: MatTableDataSource<User>;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
displayedColumns: string[] = ['email', 'usertype', 'status', 'assign_role'];
private postsSub: Subscription;
private authStatusSub: Subscription;
  constructor(private ls:LeadserviceService,private route: ActivatedRoute,
    private router: Router,public dialog: MatDialog) { }
    

    ngOnInit() {
      this.postsSub =this.ls
        .user_list()
        .subscribe((data: User[]) => {
          this.user_list = data;
         //console.log(this.user_list);
         this.show = false; 
          this.dataSource = new MatTableDataSource(this.user_list);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
          
      });
     
      this.ls
      .assign_role_type()
      .subscribe((data: RoleType[]) => {

        
        //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
        
        this.assign_role = data;
        //console.log(this.assign_role);
        
        
    }); 
      
     
  
    }
    applyFilter(filterValue: string) {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
      this.dataSource.filter = filterValue;
    }
    update_status(row_id,role_type_id,role_name)
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = true;
      dialogConfig1.autoFocus = true;
      dialogConfig1.width='280px';
      dialogConfig1.height='180px';
      this.ls.updateAssignRole(row_id,role_type_id,role_name).subscribe(res => {

        dialogConfig1.data = {
          
          response_data:res
    
        };
        const dialogRef = this.dialog.open(MessageboxComponent,dialogConfig1);
        //this.status_update = res;
        //console.log(this.status_update);
    });
    }
    add_user()
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = true;
      dialogConfig1.autoFocus = true;
      dialogConfig1.width='450px';
      dialogConfig1.height='600px';
      const dialogRef = this.dialog.open(AddUserComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        console.log(result);
        });
     
    }
    

}
