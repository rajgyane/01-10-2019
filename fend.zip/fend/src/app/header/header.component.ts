import { Component, OnInit } from '@angular/core';
import { LeadserviceService} from '../leadservice.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userIsAuthenticated = false;
  user_type:string;
  showFiller = false;
  constructor(private _ls:LeadserviceService,private route:Router) { }

  ngOnInit() {
    //this.userIsAuthenticated=this._ls.loggedIn();
    //console.log(this.userIsAuthenticated);
  }
  header_set()
  {
    this.user_type=localStorage.getItem('user_type');
    this.userIsAuthenticated=this._ls.loggedIn();
    if(this.userIsAuthenticated===true){
      return true
    }else{
      return false;
    }

  }
  logout()
  {
this._ls.logout();
  }
  create_lead()
  {
    this.route.navigate(['lead/create']);
    
  }
  list_lead()
  {
    this.route.navigate(['lead']);
  }
  add_org()
  {
    this.route.navigate(['add_organization']);
  }
  dashboard()
  {
    this.route.navigate(['dashboard']);
  }
  list_org()
  {
    this.route.navigate(['list_org']);
  }
  user_list()
  {
    this.route.navigate(['user_list']);
  }
  Permission()
  {
    this.route.navigate(['permission']);
  }
}
