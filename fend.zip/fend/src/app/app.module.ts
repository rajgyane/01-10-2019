import { BrowserModule } from '@angular/platform-browser';

import {Component, Input, Directive, ViewContainerRef,  NgModule, TemplateRef } from '@angular/core'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeadAddComponent } from './lead-add/lead-add.component';
import { LeadGetComponent } from './lead-get/lead-get.component';
import { LeadEditComponent } from './lead-edit/lead-edit.component';
import {SlimLoadingBarModule} from 'ng2-slim-loading-bar';
import{ ReactiveFormsModule,FormsModule} from '@angular/forms';
import{ HttpClientModule} from '@angular/common/http';
import{ LeadserviceService} from './leadservice.service';

import { FollowupsComponent } from './followups/followups.component';
import { ViewfollowupsComponent } from './viewfollowups/viewfollowups.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';


import{MatFormFieldModule,MatInputModule,MatExpansionModule,MatIconModule,MatMenuModule,MatCheckboxModule,MatRadioModule,MatSelectModule,MatDatepickerModule,MatNativeDateModule,MatProgressSpinnerModule} from '@angular/material';
import {MatToolbarModule} from '@angular/material/toolbar';
import { HeaderComponent } from './header/header.component';

import { AddOrganizationComponent } from './add-organization/add-organization.component';
import { FileSelectDirective } from 'ng2-file-upload';
import { ListOrgComponent } from './list-org/list-org.component';
import { DialogboxComponent } from './dialogbox/dialogbox.component';
import { MatDialogModule, MatButtonModule } from '@angular/material';
import { MessageboxComponent } from './messagebox/messagebox.component';
import { EditOrgComponent } from './edit-org/edit-org.component';
import { UserListComponent } from './user-list/user-list.component';
import { AddUserComponent } from './add-user/add-user.component';
import {MatCardModule} from '@angular/material/card';
import { PermissionComponent } from './permission/permission.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GoogleChartsModule } from 'angular-google-charts';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list';
import { ViewdetailsComponent } from './viewdetails/viewdetails.component';
import { AddfollowupstatusComponent } from './addfollowupstatus/addfollowupstatus.component';
import { AddleadsourceComponent } from './addleadsource/addleadsource.component';
import { StatusListComponent } from './status-list/status-list.component';
import {MatTabsModule} from '@angular/material/tabs';
import {StatuslisttypeModule} from './statuslisttype/statuslisttype.module';


@NgModule({
  declarations: [
    AppComponent,
    LeadAddComponent,
    LeadGetComponent,
    LeadEditComponent,
    FollowupsComponent,
    ViewfollowupsComponent,
    LoginComponent,
    HeaderComponent,
    AddOrganizationComponent,FileSelectDirective, ListOrgComponent, DialogboxComponent, MessageboxComponent, EditOrgComponent, UserListComponent, AddUserComponent, PermissionComponent, DashboardComponent, ViewdetailsComponent, AddfollowupstatusComponent, AddleadsourceComponent, StatusListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,SlimLoadingBarModule,MatTabsModule,GoogleChartsModule,MatListModule,MatSidenavModule,MatProgressSpinnerModule,FormsModule,MatExpansionModule,MatCheckboxModule,MatCardModule,MatInputModule,MatSelectModule,MatDialogModule,MatDatepickerModule,MatRadioModule,MatButtonModule,MatMenuModule,MatNativeDateModule,MatToolbarModule,MatIconModule,BrowserAnimationsModule,MatSortModule,MatPaginatorModule,ReactiveFormsModule,HttpClientModule,MatFormFieldModule,MatTableModule
  ],
  exports: [StatuslisttypeModule],
  
  
  entryComponents: [
    DialogboxComponent,MessageboxComponent,AddUserComponent,ViewdetailsComponent,AddfollowupstatusComponent,AddleadsourceComponent
    ],
  providers: [LeadserviceService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
