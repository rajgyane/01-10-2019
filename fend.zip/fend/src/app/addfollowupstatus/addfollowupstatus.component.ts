import { Component, OnInit ,Inject} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {LeadserviceService} from '../leadservice.service';
import{ ActivatedRoute,Router} from '@angular/router';
import { Followupstatus} from '../followupstatus';

@Component({
  selector: 'app-addfollowupstatus',
  templateUrl: './addfollowupstatus.component.html',
  styleUrls: ['./addfollowupstatus.component.css']
})
export class AddfollowupstatusComponent implements OnInit {
  angForm: FormGroup;
  fstatus_data:Followupstatus[]=[];
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,private fb: FormBuilder,private ls:LeadserviceService,private route: ActivatedRoute,
  private router: Router) { this.createForm();}
  createForm() {
    this.angForm = this.fb.group({
      
      followupstatus: ['', Validators.required ]
      
    });
  }

  ngOnInit() {
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  add_followups()
  {
    let followups=this.angForm.value.followupstatus;
    this.ls
    .add_followupsstatus(followups)
    .subscribe((data: Followupstatus[]) => {
      this.fstatus_data = data;
      //console.log(this.fstatus_data);
      
});
    
  }

}
