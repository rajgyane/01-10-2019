import { Component,ViewChild,ChangeDetectionStrategy} from '@angular/core';
import {SlimLoadingBarService} from 'ng2-slim-loading-bar';
import { NavigationCancel,
  Event,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router } from '@angular/router';
  import { LeadserviceService} from './leadservice.service';
  

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  title = 'Lead Management System';
  userIsAuthenticated = false;
  user_type:string;
  rightSideNav = true ;
  rightSideNavstatus:string;
  menustatus=false;
  
  
  constructor(private _loadingBar: SlimLoadingBarService, private _router: Router,private _ls:LeadserviceService)
   {
    this._router.events.subscribe((event: Event) => {
      this.navigationInterceptor(event);
    });
   
    
    
  }
  private navigationInterceptor(event: Event): void {
    if (event instanceof NavigationStart) {
      this._loadingBar.start();
    }
    if (event instanceof NavigationEnd) {
      this._loadingBar.complete();
    }
    if (event instanceof NavigationCancel) {
      this._loadingBar.stop();
    }
    if (event instanceof NavigationError) {
      this._loadingBar.stop();
    }
  }
  
  
  ngOnInit(){
    
    
  }
  header_set()
  {
    
    this.user_type=localStorage.getItem('user_type');
    this.userIsAuthenticated=this._ls.loggedIn();
    //this.rightSideNav = true;
    if(this.userIsAuthenticated===true){
    
      return true;
    }else{
    
      return false;
    }

  }
  sideNavBtnToggle(){
    if(this.rightSideNav == false)
    {
      this.rightSideNav  = true;
    }
    else{
      this.rightSideNav  = false;
    } 
    //console.log(this.rightSideNav);
}
change_menu_status()
{
  if(this.menustatus == false)
  {
    this.menustatus  = true;
  }
  else{
    this.menustatus  = false;
  }
  console.log(this.menustatus); 

}
  logout()
  {
    //this.rightSideNav  = false;
this._ls.logout();



  }
}
