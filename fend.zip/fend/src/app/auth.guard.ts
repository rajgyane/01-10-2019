import { Injectable } from '@angular/core';
import { CanActivate,Router  } from '@angular/router';
import {LeadserviceService} from './leadservice.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private _ls:LeadserviceService,private _route:Router)
  {

  }
  canActivate(): boolean {
    if(this._ls.loggedIn())
    {
return true;
    }
    else{
      this._route.navigate(['/login']);
      return false;
    }
  }
  
}
