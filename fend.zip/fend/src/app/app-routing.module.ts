import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LeadAddComponent} from './lead-add/lead-add.component';
import {LeadGetComponent} from './lead-get/lead-get.component';
import {LeadEditComponent} from './lead-edit/lead-edit.component';
import { FollowupsComponent} from './followups/followups.component';
import { ViewfollowupsComponent } from './viewfollowups/viewfollowups.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import {AddOrganizationComponent} from './add-organization/add-organization.component';
import {ListOrgComponent} from './list-org/list-org.component';
import { EditOrgComponent} from './edit-org/edit-org.component';
import { UserListComponent} from './user-list/user-list.component';
import { PermissionComponent} from './permission/permission.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import{ StatusListComponent} from './status-list/status-list.component';
import { StatuslisttypeComponent} from './statuslisttype/statuslisttype.component';


const routes: Routes = [
  {path: "", redirectTo: '/login',pathMatch:'full'},
{path:'lead/create',component:LeadAddComponent,canActivate:[AuthGuard]},
{path:'edit/:id',component:LeadEditComponent,canActivate:[AuthGuard]},
{path:'lead',component:LeadGetComponent,canActivate:[AuthGuard]},
{path:'followup/:id',component:FollowupsComponent,canActivate:[AuthGuard]},
{path:'viewfollowup/:id',component:ViewfollowupsComponent,canActivate:[AuthGuard]},
{path:'add_organization',component:AddOrganizationComponent,canActivate:[AuthGuard]},
{path:'list_org',component:ListOrgComponent,canActivate:[AuthGuard]},
{path:'edit_org/:id',component:EditOrgComponent,canActivate:[AuthGuard]},
{path:'user_list',component:UserListComponent,canActivate:[AuthGuard]},
{path:'permission',component:PermissionComponent,canActivate:[AuthGuard]},
{path:'dashboard',component:DashboardComponent,canActivate:[AuthGuard]},
//{path:'statuslisttype',loadChildren: './statuslisttype/statuslisttype.module#statuslisttype',canActivate:[AuthGuard], pathMatch: 'full'},
{path:'login',component:LoginComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
