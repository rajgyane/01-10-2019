import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { LeadserviceService } from '../leadservice.service';
import  lead  from '../lead';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.css']
})
export class ViewdetailsComponent implements OnInit {
  Lead:lead[]= [];

  constructor(public dialogRef: MatDialogRef<lead>,@Inject(MAT_DIALOG_DATA)public data: any,private ls:LeadserviceService) { }

  ngOnInit() {
    console.log(this.data.id);
    this.ls
      .getDetails(this.data.id)
      .subscribe((data: lead[]) => {
        this.Lead = data;
        console.log(this.Lead);
       });
    //console.log(this.data.id);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  

}
