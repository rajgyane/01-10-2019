const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Permission = new Schema({
    org_name:{type:String},
    module_id:{type: String},
    module_status:{type: String},
    role_id:{type: String},
},{
    collection: 'permission'
});
module.exports = mongoose.model('Permission', Permission);