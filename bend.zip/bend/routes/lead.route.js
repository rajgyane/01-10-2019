const express = require('express');
const app = express();
const businessRoutes = express.Router();
const jwt=require("jsonwebtoken");
const multer = require('multer');
const moment = require('moment-timezone');

const dateIndia = moment.tz(Date.now(), "Asia/Kolkata");
//console.log(dateIndia);
//var QRCode = require('qrcode')
 
/*QRCode.toDataURL('I am a pony!', function (err, url) {
  //console.log(url+'fdwadsFfaSDDG');
})*/


// Require Business model in our routes module
let Business = require('../models/Lead');
let Followups=require('../models/followup');
let Users=require('../models/users');
let Country=require('../models/country');
let State=require('../models/state');
let District=require('../models/district');
let Add_org=require('../models/add_org');
let role_type=require('../models/role_type');
let city=require('../models/city');
let class1=require('../models/class');
let lead_source =require('../models/lead_source');
let followupstatus=require('../models/followupstatus');
let modulelist=require('../models/module');
let permission_list=require('../models/permission');
let newfilname ="";

const DIR = './uploads';
let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    newfilname =file.fieldname + '-' + Date.now() + path.extname(file.originalname);
    cb(null, newfilname);
  }
});
let upload = multer({storage: storage});

businessRoutes.route('/upload').post(upload.single('photo'),function(req,res)
{
 
  if (!req.file) {
    //console.log("No file received");
    return res.send({
      success: false
    })

  } else {
    //console.log('file received');

    
    return res.send({
      newfilename:newfilname,
      success: true
    })
  }
});




businessRoutes.route('/addorganization').post(function(req,res)
{
  let add_org = new Add_org(req.body);
  add_org.full_name_org=req.body.org_name;
  add_org.org_aliase=req.body.org_alise;
  add_org.logo=req.body.upload_image;
  add_org.address=req.body.org_address;
  add_org.status='1';
  add_org.save()
    .then(business => {
      res.status(200).json("Add Organization  Record successfully");
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
  
})

//check user ..
businessRoutes.route('/login').post(function(req,res){
  let User=new Users(req.body);
  //console.log(User);
  Users.findOne({email:User.email},function(err,user){
//console.log(User.email);
    if(err)
    {
      res.status(400).json({
        message: "Login failed"
      });
      
    }
    else{
      if(!user)
      {
        res.status(201).json({
          message: "Login failed"
        });
        
      }
      else{
        if(user.password==User.password)
        {
          let payLoad={subject:user._id};
          let token=jwt.sign(payLoad,'secretKey');
          res.status(200).json({
            message: "Succuss",usertype:user.usertype,token:token,assign_role:user.assign_role,org_id:user.org_id
          });
          
        }
        else{
          res.status(201).json({
            message: "Login failed"
          });
        }
      }
    }
  })
  
})


//add followups
businessRoutes.route('/add_followups/:id').post(function (req, res) {
  // console.log(req.params.id);
 // let id = req.params.id;
 //console.log(req.body);
  let followups = new Followups(req.body);
  followups.save()
    .then(business => {
      res.status(200).json("Followup added successfully");
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });

    // console.log(err);
});


// Defined store route
businessRoutes.route('/add').post(function (req, res) {
  var myobj ={
  "student_name":req.body.student_name,
  "mobile_no":req.body.mobile_no,
  "email_address":req.body.email_address,
  "class_apply":req.body.class_apply,
  "country":req.body.country,
  "state":req.body.state,
  "city":req.body.city,
  "occupation":req.body.occupation,
  "annual_income":req.body.annual_income,
  "query":req.body.query,
  "district":req.body.district,
  "pincode":req.body.pincode,
  "lead_source":req.body.leadsource,
  "org_id":req.body.orgname,
  "creation_date":dateIndia,
 };

 Business.create(myobj,function(err,res1){
  if(err) res.status(400).send("unable to save to database");
  else{  res.status(200).json("Lead added successfully");}
  
});
})
//get permission list..
businessRoutes.route('/permission_list').get(function(req,res){
permission_list.find({},function(err,plist){
  if(err)res.json(err);
  else{
    res.json(plist);
  }

})

})

//add or update permission
businessRoutes.route('/assign_permission').post(function(req,res)
{ //console.log(req.body.org+'msg1');
  permission_list.findOne({org_name:req.body.org,module_id:req.body.modules,role_id:req.body.role},function(err,permissiondata){
   //console.log(req.body.org+'msg2');
    if(err)res.json(err)
    else{
      if(permissiondata!='' && permissiondata!=null)
      {
        //console.log(permissiondata,'dhagfgdfgsajdkfgsjdkf');
        //console.log(req.body.org,'tttttttttttttt');
        
         permissiondata.org_name=req.body.org;
         permissiondata.module_id=req.body.modules;
         permissiondata.role_id=req.body.role;
        // console.log(req.body.status,'update');
         if(req.body.status==true)
         {
           permissiondata.module_status='1';
         }
        else{
            permissiondata.module_status='0';
         }
       // console.log(permissiondata.module_status,'update');
        permissiondata.save().then(permission => {
          res.json('Update Permission Successfully');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });

      }
      else{
        //console.log(req.body.status,'insert');
        if(req.body.status==true)
        {
          req.body.status='1';
        }
        else{
          req.body.status='0';
        }
       //console.log(req.body.status,'insert');
        var myobj ={
          "org_name":req.body.org,
          "module_id":req.body.modules,
          "role_id":req.body.role,
          "module_status":req.body.status,
          
         };
         permission_list.create(myobj,function(err,res1){
          if(err) res.status(400).send("unable to Modify Permission");
          else{  res.status(200).json("Create Permission Successfully");}
          
        });
      }
    }
  })
  
}
)
//get list organization data

businessRoutes.route('/list_organization').get(function(req,res){
  Add_org.find({'status':1},function(err,add_org){
    if(err)
    {
      console.log(err);
    }
    else{
      res.json(add_org);
    }
  }).sort({_id:-1})
})
//get class list..
businessRoutes.route('/getclasslist').get(function(req,res){
  class1.find({},function(err,cl)
  {
    if(err)res.json(err);
    else{
      res.json(cl);
    }
  }).sort({_id:-1})

})
//get lead source..
businessRoutes.route('/getleadsourcelist').get(function(req,res){
  lead_source.find({},function(err,ls){
if(err)res.json(err);
else{ res.json(ls);}

  })
})
//get role type..
businessRoutes.route('/assign_role_type').get(function(req,res){
  role_type.find({ role_id: { $ne: '4' } },function(err,role){
    if(err){ res.json(err);}
    else{
      res.json(role);
    }
  }) 
})

//add lead source...
businessRoutes.route('/add_leadsourcedata').post(function(req,res){
  lead_source.findOne({"lead_source_name":req.body.leadsource},function(err,lresponce)
  {
    if(err) res.json("Error Rise");
    if(lresponce!=null)
    {
      res.json('Lead Source Name Already Exists');
    }
    else
    {
      lead_source.find({},{lead_source_id:1},function(err,source){

        let lead_source_id='';
        if(source!='')
        {
          lead_source_id=parseInt(source[0].lead_source_id);
        }
        else{
          lead_source_id=0;
        }
        lead_source_id=lead_source_id+1;
        var myobj={'lead_source_name':req.body.leadsource,'lead_source_id':lead_source_id};
        lead_source.create(myobj,function(err,res1)
        {
          if(err)res.json(err);
          else{ res.json('Added Lead Source Successfully');}
        })
    
      }).sort({ _id: -1 }).limit(1)
    }

  })
  

})
//add followups status...

businessRoutes.route('/addFollowupstatus').post(function(req,res){
  let follupstatus=req.body.followups;
  followupstatus.findOne({"status_name":follupstatus},function(err,resp)
  {
    
    if(err)res.json('Error Rise');

   if(resp!=null)
    {
      res.json('FollowUp Status already Added');
    }
    else{
      console.log('else');
      followupstatus.find({},{status_id:1},function(err,status)
  {
    let status_id='';
    if(status!='')
    {
      status_id= parseInt(status[0].status_id);
    }
    else{
      status_id=0;
    }
    
    status_id=status_id+1;
    var myobj = { "status_name":req.body.followups,"status_id":status_id};
    followupstatus.create(myobj,function(err,res1)
  {
    if(err)res.json(err);
    else{ res.json('Added Status Successfully');}
  })

  }).sort({ _id: -1 }).limit(1)

    }

  })
  
  //var myobj = { "status_name":req.body.followups,"status_id":get_last_status_id()};
  //console.log(myobj);

})

//get user data..


businessRoutes.route('/user_list_data').get(function(req,res){
  Users.find({ assign_role: { $ne: '4' } },function(err,add_org){
    if(err)
    {
      console.log(err);
    }
    else{
      res.json(add_org);
    }
  }).sort({_id:-1})
})


//get country data
businessRoutes.route('/country').get(function(req,res){
  Country.find({},function(err,countrys){
    if(err){
      console.log(err);
    }
    else {
      //console.log(countrys);
      res.json(countrys);
    }
  });
});
//edit followup status data...

//edit_followupstatus_data
businessRoutes.route('/edit_followupstatus_data').post(function(req,res){
let id=mongoose.Types.ObjectId(req.body.action_id);
followupstatus.findOne({"_id":id},function(err,data)
{
  if(err)res.json(err);
  if(data!=null)
  {
    res.json(data);
  }


})

})

//modified status data..
businessRoutes.route('/edit_followups_update').post(function(req,res){
  let id=mongoose.Types.ObjectId(req.body.action_id);
  followupstatus.findOne({"_id":id},function(err,data)
{
  if(err)res.json(err);
  if(data!=null)
  {
    data.status_name=req.body.change_value;
    data.save().then(lsource => {
        res.json('Modify Followup Status Successfully');
    })
    .catch(err => {
          res.status(400).send("unable to update the database");
    });
  }


})


})
//....
//delete lead source..
//deleteleadsourcedata..
businessRoutes.route('/deleteleadsourcedata').post(function(req,res){
  let id=mongoose.Types.ObjectId(req.body.action_id);
  //console.log(id);
  lead_source.deleteOne({"_id": id}, function(err, business){
    if(err) res.json(err);
    else res.json('Successfully Removed');
});
})
//delete followup status data..

businessRoutes.route('/deletefollowupsstatusdata').post(function(req,res){
  let id=mongoose.Types.ObjectId(req.body.action_id);
  followupstatus.deleteOne({"_id": id}, function(err, business){
    if(err) res.json(err);
    else res.json('Successfully Removed');
});

})
//modify lead source..
businessRoutes.route('/edit_lead_source_data_update').post(function(req,res){

  let id=mongoose.Types.ObjectId(req.body.action_id);
  lead_source.findOne({"_id":id},function(err,dat){
    if(err)res.json('Unable To Find');
    if(dat!=null)
    {
      dat.lead_source_name=req.body.source_name;
      dat.save().then(lsource => {
        res.json('Modify Lead Source Successfully');
    })
    .catch(err => {
          res.status(400).send("unable to update the database");
    });

    }
  })
})
//edit lead source list...

businessRoutes.route('/edit_lead_source_data').post(function(req,res)
{
  let id=mongoose.Types.ObjectId(req.body.id);
  lead_source.findOne({"_id":id},function(err,dat){
if(err)res.json("Error Rise");
else if(dat!=null)
{
  res.json(dat);
}

  })

})
//view deatils
businessRoutes.route('/getDetails').post(function (req, res) {
  let userId =  mongoose.Types.ObjectId(req.body.id);
  

  Business.aggregate([
    { 
      $match: {_id:  userId} 
  },
    {
        $lookup: {
            from: "state",
            localField: "state",
            foreignField: "state_id",
            as: "statedata"
        }
    },
    {
      $lookup: {
        from: "district",
        localField: "district",
        foreignField: "district_id",
        as: "districtdata"
      }
  },
  {
    $lookup: {
      from: "city",
      localField: "city",
      foreignField: "id",
      as: "citydata"
    }
}
,
{
  $lookup: {
    from: "add_org",
    localField: "org_id",
    foreignField: "_id",
    as: "orgdata"
  }
},
  {
    $lookup: {
      from: "class",
      localField: "class_apply",
      foreignField: "class_id",
      as: "classdata"
    }
},
{
  $lookup: {
    from: "lead_source",
    localField: "lead_source",
    foreignField: "lead_source_id",
    as: "leadsource"
  }
},
{
  $lookup: {
    from: "followups",
    localField: "_id",
    foreignField: "ref",
    as: "followups"
    
  }
},
{
$lookup: {
    from: "followup_status",
    localField: "followups.status",
    foreignField: "status_id",
    as: "followup_status"
}
},

 { "$addFields": {
   "followup": { "$slice": ["$followups", -1] }
 }},
 
 
 
],function (err, businesses){
  //console.log(businesses+'cdasfsa');

 /*followupstatus.find({'status_id':businesses.followup[0].status},function(err,dtaa){
  console.log(dtaa);
  res.json(dtaa);
  })*/
  
  if(err){
    console.log(err);
  }
  else {
    //console.log(businesses);
    res.json(businesses);
  }
});
});
// Defined get data(index or listing) route
businessRoutes.route('/').get(function (req, res) {
    Business.aggregate([
      {
          $lookup: {
              from: "state",
              localField: "state",
              foreignField: "state_id",
              as: "statedata"
          }
      },
      {
        $lookup: {
          from: "district",
          localField: "district",
          foreignField: "district_id",
          as: "districtdata"
        }
    },
    {
      $lookup: {
        from: "city",
        localField: "city",
        foreignField: "id",
        as: "citydata"
      }
  }
  ,
    {
      $lookup: {
        from: "class",
        localField: "class_apply",
        foreignField: "class_id",
        as: "classdata"
      }
  },
  {
    $lookup: {
      from: "lead_source",
      localField: "lead_source",
      foreignField: "lead_source_id",
      as: "leadsource"
    }
},
  {
    $lookup: {
      from: "followups",
      localField: "_id",
      foreignField: "ref",
      as: "followups"
      
    }
},
{
  $lookup: {
      from: "followup_status",
      localField: "followups.status",
      foreignField: "status_id",
      as: "followup_status"
  }
},
   { "$addFields": {
     "followup": { "$slice": ["$followups", -1] }
   }},
   
   
   
  ],function (err, businesses){
    //console.log(businesses+'cdasfsa');

   /*followupstatus.find({'status_id':businesses.followup[0].status},function(err,dtaa){
    console.log(dtaa);
    res.json(dtaa);
    })*/
    
    if(err){
      console.log(err);
    }
    else {
      //console.log(businesses);
      res.json(businesses);
    }
  });
});
//get city name..
businessRoutes.route('/Citylist/:disid').get(function(req,res){
  let districtid=req.params.disid;
  city.find({district_id:districtid},function(err,citys){
if(err) res.json(err);
else { res.json(citys);}

  })
  
})
//get pincode..

businessRoutes.route('/getPincode/:cityid').get(function(req,res){
  let cityid=req.params.cityid;
  city.find({id:cityid},function(err,citys){
    if(err) res.json(err);
    else { res.json(citys);}
  })
})
//get module list
//module_list
//get last followups.modulelist
businessRoutes.route('/module_list').get(function(req,res){
  modulelist.find({},function(err,modulee){

    if(err)res.json(err);
    else {res.json(modulee);}
  })
})

businessRoutes.route('/lastFollowup/:id').get(function (req, res) {
  let ref = mongoose.Types.ObjectId(req.params.id);
  Followups.aggregate([{
    $match : { ref:  ref}
},
    
   {
      $lookup:
         {
            from: "followup_status",
            localField: "status",
            foreignField: "status_id",
            as: "statusdata"
        }
   }
   
  ],function(err,business){
if(err)res.json(err);
else{
  res.json(business);
}

  })

  
 
});
//get followup status list..

businessRoutes.route('/getFolowupstatuslist').get(function(req,res){
  followupstatus.find({},function(err,followipsss){
    if(err)res.json(err);
    else{
      res.json(followipsss);
    }

  })
})
//get followups



businessRoutes.route('/listFollowups/:id').get(function (req, res) {
  let ref = req.params.id;
  Followups.find({ref:ref},function(err,business)
   {res.json(business);});
 });

// Defined edit route

businessRoutes.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
  Business.findById(id, function (err, business){
      res.json(business);
  });
});
//edit org data..

businessRoutes.route('/editorg/:id').get(function (req, res) {
    Add_org.findById({_id: req.params.id}, function (err, business){
      res.json(business);
  });
});
//get state name
businessRoutes.route('/state_list/:cid').get(function (req,res){
  let Country_code=req.params.cid;
  //console.log(Country_code);
  State.find({ Country_code:Country_code },function(err,states){
    res.json(states);
    //console.log(states);
  })

} )
//get alloted email id


businessRoutes.route('/check_alloted_email').post(function(req,res){
  Users.find({email:req.body.email},function(err,userss){
    if(err)res.json(err);
    else{
      if(userss!=''){ res.json(true)}else{res.json(false)}
    }

  })
})
//get district name..district_list
businessRoutes.route('/district_list/:sid').get(function(req,res)
{
let sid=req.params.sid;
District.find({state_id:sid},function(err,districts){
  res.json(districts);
})

})

//update role type..

businessRoutes.route('/updateAssignRole/:uid').post(function(req,res)
{
  //console.log(req.params.uid);
  Users.findById({_id:req.params.uid},function(err,userss)
  {
    if(err)res.json(err);
    else{
      //console.log(req.body.role_type_id);
      userss.assign_role=req.body.role_type_id;
      userss.usertype=req.body.role_name;
      userss.save().then(user1 => {
        res.json('Modify User Type Successfully');
    })
    .catch(err => {
          res.status(400).send("unable to update the database");
    });
    }

  })
})

//update org data..
businessRoutes.route('/updateOrgdata/:id').post(function (req,res){
  Add_org.findById({_id: req.params.id},function(err, business){
    if(err)res.json(err);
    else{
      business.full_name_org=req.body.full_name_org;
      if(req.body.logo!='')
      {
        business.logo=req.body.logo;
      }
      business.address=req.body.address;
      business.org_aliase=req.body.org_aliase;
      business.status=req.body.org_status;
      business.save().then(business => {
        res.json('Update complete');
    })
    .catch(err => {
          res.status(400).send("unable to update the database");
    });
    }
  }) 
})
//create_new_user
businessRoutes.route('/create_new_user').post(function(req,res)
{
  var myobj = { "email":req.body.useremail,"password":req.body.password,"usertype":req.body.role_name,"status":1,"assign_role":req.body.role_id,"org_id":req.body.organization,"user_full_name":req.body.userfullname }; 
  Users.create(myobj,function(err,res1)
  {
if(err)res.json(err);
else{ res.json('User Created Successfully');}

  })
  //User.email=req.body.useremail;
  //console.log(req.body.useremail);
})
//update full profile of student...
businessRoutes.route('/updateProfile/:id').post(function (req, res) {
  Business.findById({_id: req.params.id}, function(err, business){
    if(err) res.json(err);
    else{
    
      business.student_name = req.body.student_name;
      business.class_apply = req.body.class_apply;
      business.email_address = req.body.email_address;
      business.mobile_no = req.body.mobile_no;
      business.address1 = req.body.address1;
      business.address2 = req.body.address2;
      business.city = req.body.city;
      business.state = req.body.state;
      business.pin = req.body.pin;
      business.information_source = req.body.information_source;
      business.father_name = req.body.father_name;
      business.mother_name = req.body.mother_name;
      business.occupation = req.body.occupation;
      business.mother_occupation = req.body.mother_occupation;
      business.father_org = req.body.father_org;
      business.mother_org = req.body.mother_org;
      business.father_designation = req.body.father_designation;
      business.mother_designation = req.body.mother_designation;
      business.alter_mobile_no = req.body.alter_mobile_no;
      business.alter_email = req.body.alter_email;
      business.current_school = req.body.current_school;
      business.percentage = req.body.percentage;
      business.dob = req.body.dob;
      business.gender = req.body.gender;
      business.sports = req.body.sports;
      business.activity = req.body.activity;
      business.no_of_brother = req.body.no_of_brother;
      business.no_of_sister = req.body.no_of_sister;
      business.brother_school_name1 = req.body.brother_school_name1;
      business.brother_school_name2 = req.body.brother_school_name2;
      business.sister_school_name1 = req.body.sister_school_name1;
      business.sister_school_name2 = req.body.sister_school_name2;
      business.reason_for_change = req.body.reason_for_change;

      business.save().then(business => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  

  });
});


//  Defined update route
businessRoutes.route('/update/:id').post(function (req, res) {
  console.log(req.params.id);
  Business.findById({_id: req.params.id}, function(err, business){
    if(err) res.json(err);
    else{

      
      business.student_name = req.body.student_name;
      business.mobile_no = req.body.mobile_no;
      business.email_address = req.body.email_address;
      business.class_apply = req.body.class_apply;
      business.state = req.body.state;
      business.city = req.body.city;
      business.occupation = req.body.occupation;
      business.annual_income = req.body.annual_income;
      business.query = req.body.query;
      business.district=req.body.district;
      business.pincode=req.body.pincode;
      business.country=req.body.country;
      business.lead_source=req.body.leadsource;
      business.org_id=req.body.orgname;
      modify_date=dateIndia;

      


      business.save().then(business => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  

  });
});
   


// Defined delete | remove | destroy route
businessRoutes.route('/delete/:id').get(function (req, res) {
    Business.deleteOne({_id: req.params.id}, function(err, business){
        if(err) res.json(err);
        else res.json('Successfully Removed');
    });
});
//Delete Organization ...
businessRoutes.route('/deleteorg/:id').get(function(req,res){
  //console.log(req.param.id);
    Add_org.findById({_id:req.params.id},function(err,business){
    if(err) res.json(err);
    else
    business.status = '0';
    business.save().then(business => {
      res.json('Successfully Removed');
  })
  .catch(err => {
        res.status(400).send("unable to update the database");
  });
    
  });

});

module.exports = businessRoutes;